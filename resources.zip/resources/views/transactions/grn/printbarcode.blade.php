
<style>
			table.report1{
			font-family: "Times new Roman";
			border-collapse: collapse;
			font-size: 0.9em;
			}

			.report1 th,.report1 td{
			padding: 3px;
			}
			.subh2{
			font-size: 0.9em;
			white-space: nowrap;
			}
			.left{ text-align: left; }
			.right{ text-align: right; }

			h3,h2{
			line-height: 100%;
			}
			p {
			line-height: 0.8em;
			}
		</style>



        <div >
        @foreach ($contents as $content )

			<table  class="report1" >
				<thead>


				</thead>

				<tbody>
                        <tr>
                            <td>
                                {{-- {!! QrCode::size(200)->generate($pr->serial_no); !!} --}}
                                {{$content['barcode']}}
                            </td>
                        </tr>
                        <tr>
                           <td>
                           {{$content['transaction_number']}}<br>
                            {{$content['item_name']}}<br>
                            {{$content['spq_quantity']}}<br>

                           </td>
                        </tr>


				</tbody>
			</table>
            <br>
                        <br>

        @endforeach
        </div>




<script>
    window.print();
    window.onafterprint = function(){
        window.close();
    }
</script>
