<?php

namespace App\Models\Sidebar;

use Illuminate\Database\Eloquent\Model;

class Submenu extends Model
{
    //
}
